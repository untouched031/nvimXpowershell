-- plugins/init.lua
--
-- Plugin specs for lazy.nvim. The language-tooling plugins (treesitter,
-- mason-lspconfig, mason-tool-installer, mason-nvim-dap) no longer list
-- languages by hand: their ensure_installed is built from
-- registry/languages.json at config-time, from whichever languages are
-- currently marked installed. lang_setup.lua handles anything added later
-- in the same running session; these lists just need to be right for the
-- NEXT startup.

local registry_ok, registry = pcall(require, "lang_registry")

local function installed_entries()
  if not registry_ok then return {} end
  local reg = registry.get_registry()
  if not reg then return {} end
  local ids = registry.get_installed_lang_ids()
  local entries = {}
  for _, id in ipairs(ids) do
    table.insert(entries, reg.languages[id])
  end
  return entries
end

local function collect_unique(entries, field_getter)
  local seen, out = {}, {}
  for _, entry in ipairs(entries) do
    local vals = field_getter(entry)
    if vals then
      for _, v in ipairs(vals) do
        if v and not seen[v] then
          seen[v] = true
          table.insert(out, v)
        end
      end
    end
  end
  table.sort(out)
  return out
end

local function treesitter_ensure_installed()
  return collect_unique(installed_entries(), function(e) return e.treesitter end)
end

local function mason_lsp_ensure_installed()
  -- mason-lspconfig's ensure_installed takes lspconfig server names (it does
  -- its own name translation internally), matching registry.<lang>.lsp.server.
  local out = {}
  local seen = {}
  for _, entry in ipairs(installed_entries()) do
    if entry.lsp and entry.lsp ~= vim.NIL and entry.lsp.server and entry.lsp.server ~= vim.NIL then
      if not seen[entry.lsp.server] then
        seen[entry.lsp.server] = true
        table.insert(out, entry.lsp.server)
      end
    end
  end
  table.sort(out)
  return out
end

local function mason_tools_ensure_installed()
  -- Raw Mason package names for formatters/linters (no name-translation
  -- layer exists for these the way LspInstall provides for LSP servers).
  local out, seen = {}, {}
  for _, entry in ipairs(installed_entries()) do
    if entry.mason and entry.mason ~= vim.NIL then
      for _, key in ipairs({ "formatter", "linter" }) do
        local v = entry.mason[key]
        if v and v ~= vim.NIL and not seen[v] then
          seen[v] = true
          table.insert(out, v)
        end
      end
    end
  end
  table.sort(out)
  return out
end

local function mason_dap_ensure_installed()
  local out, seen = {}, {}
  for _, entry in ipairs(installed_entries()) do
    if entry.dap and entry.dap ~= vim.NIL and entry.dap.kind == "mason" and entry.dap.mason_pkg and entry.dap.mason_pkg ~= vim.NIL then
      if not seen[entry.dap.mason_pkg] then
        seen[entry.dap.mason_pkg] = true
        table.insert(out, entry.dap.mason_pkg)
      end
    end
  end
  table.sort(out)
  return out
end

local function conform_formatters_by_ft()
  local out = {}
  for _, entry in ipairs(installed_entries()) do
    if entry.conform and entry.conform ~= vim.NIL then
      for _, ft in ipairs(entry.filetypes) do
        out[ft] = { entry.conform }
      end
    end
  end
  return out
end

local function lint_linters_by_ft()
  local out = {}
  for _, entry in ipairs(installed_entries()) do
    if entry.lint and entry.lint ~= vim.NIL then
      for _, ft in ipairs(entry.filetypes) do
        out[ft] = { entry.lint }
      end
    end
  end
  return out
end

return {

  -- ---------------------------------------------------------------
  -- Treesitter: syntax highlighting + text objects
  -- ---------------------------------------------------------------
  {
    "nvim-treesitter/nvim-treesitter",
    branch = "main",
    build = ":TSUpdate",
    lazy = false,
    config = function()
      require("nvim-treesitter").setup({
        ensure_installed = treesitter_ensure_installed(),
        auto_install = false, -- lang_setup.lua's FileType autocmd handles this instead
      })
      -- Generic highlighting-start autocmd lives in lang_setup.lua so there
      -- is exactly one place that decides "does this buffer get treesitter".
    end,
  },

  -- ---------------------------------------------------------------
  -- Mason + LSP
  -- ---------------------------------------------------------------
  {
    "mason-org/mason.nvim",
    lazy = false,
    priority = 100,
    opts = {
      ui = { border = "rounded" },
    },
  },
  {
    "mason-org/mason-lspconfig.nvim",
    dependencies = { "mason-org/mason.nvim", "neovim/nvim-lspconfig" },
    lazy = false,
    opts = {
      ensure_installed = mason_lsp_ensure_installed(),
      automatic_enable = false, -- lsp.lua decides enabling (default langs now, on-demand ones later)
    },
  },
  {
    "neovim/nvim-lspconfig",
    lazy = false,
    config = function()
      require("lsp").setup()
    end,
  },
  {
    "WhoIsSethDaniel/mason-tool-installer.nvim",
    dependencies = { "mason-org/mason.nvim" },
    lazy = false,
    opts = {
      ensure_installed = mason_tools_ensure_installed(),
      run_on_start = true,
      start_delay = 1000,
    },
  },
  {
    "hrsh7th/nvim-cmp",
    event = "InsertEnter",
    dependencies = {
      "hrsh7th/cmp-nvim-lsp",
      "hrsh7th/cmp-buffer",
      "hrsh7th/cmp-path",
      "L3MON4D3/LuaSnip",
      "saadparwaiz1/cmp_luasnip",
    },
    config = function()
      local cmp = require("cmp")
      local luasnip = require("luasnip")
      cmp.setup({
        snippet = {
          expand = function(args) luasnip.lsp_expand(args.body) end,
        },
        mapping = cmp.mapping.preset.insert({
          ["<C-Space>"] = cmp.mapping.complete(),
          ["<C-e>"] = cmp.mapping.abort(),
          ["<CR>"] = cmp.mapping.confirm({ select = true }),
          ["<Tab>"] = cmp.mapping(function(fallback)
            if cmp.visible() then cmp.select_next_item()
            elseif luasnip.expand_or_jumpable() then luasnip.expand_or_jump()
            else fallback() end
          end, { "i", "s" }),
          ["<S-Tab>"] = cmp.mapping(function(fallback)
            if cmp.visible() then cmp.select_prev_item()
            elseif luasnip.jumpable(-1) then luasnip.jump(-1)
            else fallback() end
          end, { "i", "s" }),
        }),
        sources = cmp.config.sources({
          { name = "nvim_lsp" },
          { name = "luasnip" },
        }, {
          { name = "buffer" },
          { name = "path" },
        }),
      })
    end,
  },

  -- ---------------------------------------------------------------
  -- Formatting / linting
  -- ---------------------------------------------------------------
  {
    "stevearc/conform.nvim",
    event = { "BufWritePre" },
    cmd = { "ConformInfo" },
    keys = {
      { "<leader>f", function() require("conform").format({ async = true, lsp_fallback = true }) end, desc = "Format buffer" },
    },
    opts = {
      formatters_by_ft = conform_formatters_by_ft(),
      format_on_save = { timeout_ms = 2000, lsp_fallback = true },
    },
  },
  {
    "mfussenegger/nvim-lint",
    event = { "BufWritePost", "BufReadPost", "InsertLeave" },
    config = function()
      local lint = require("lint")
      lint.linters_by_ft = lint_linters_by_ft()
      vim.api.nvim_create_autocmd({ "BufWritePost", "BufReadPost", "InsertLeave" }, {
        group = vim.api.nvim_create_augroup("DevEnvLint", { clear = true }),
        callback = function() lint.try_lint() end,
      })
    end,
  },

  -- ---------------------------------------------------------------
  -- Debugging
  -- ---------------------------------------------------------------
  { "mfussenegger/nvim-dap", lazy = false },
  {
    "rcarriga/nvim-dap-ui",
    dependencies = { "mfussenegger/nvim-dap", "nvim-neotest/nvim-nio" },
    lazy = false,
  },
  {
    "jay-babu/mason-nvim-dap.nvim",
    dependencies = { "mason-org/mason.nvim", "mfussenegger/nvim-dap" },
    lazy = false,
    opts = {
      ensure_installed = mason_dap_ensure_installed(),
      automatic_installation = true,
      handlers = {}, -- {} = use mason-nvim-dap's own default handler for every adapter it knows
    },
    config = function(_, opts)
      require("mason-nvim-dap").setup(opts)
      require("dap_config").setup()
    end,
  },

  -- ---------------------------------------------------------------
  -- Everything below is unrelated to per-language tooling and unchanged
  -- in spirit from before -- fuzzy finding, file tree, UI chrome, git
  -- signs, terminal, and quality-of-life editing plugins.
  -- ---------------------------------------------------------------
  {
    "nvim-telescope/telescope.nvim",
    dependencies = { "nvim-lua/plenary.nvim" },
    cmd = "Telescope",
    keys = {
      { "<leader>ff", "<cmd>Telescope find_files<cr>", desc = "Find files" },
      { "<leader>fg", "<cmd>Telescope live_grep<cr>", desc = "Live grep" },
      { "<leader>fb", "<cmd>Telescope buffers<cr>", desc = "Buffers" },
      { "<leader>fh", "<cmd>Telescope help_tags<cr>", desc = "Help tags" },
    },
  },
  {
    "nvim-tree/nvim-tree.lua",
    dependencies = { "nvim-tree/nvim-web-devicons" },
    cmd = { "NvimTreeToggle", "NvimTreeFindFile" },
    keys = {
      { "<leader>e", "<cmd>NvimTreeToggle<cr>", desc = "Toggle file tree" },
    },
    opts = {},
  },
  {
    "akinsho/toggleterm.nvim",
    cmd = "ToggleTerm",
    keys = {
      { "<C-\\>", "<cmd>ToggleTerm<cr>", desc = "Toggle terminal" },
    },
    opts = { direction = "float" },
  },
  {
    "nvim-lualine/lualine.nvim",
    dependencies = { "nvim-tree/nvim-web-devicons" },
    event = "VeryLazy",
    opts = {},
  },
  {
    "akinsho/bufferline.nvim",
    dependencies = { "nvim-tree/nvim-web-devicons" },
    event = "VeryLazy",
    opts = {},
  },
  {
    "lewis6991/gitsigns.nvim",
    event = { "BufReadPre", "BufNewFile" },
    opts = {},
  },
  {
    "lukas-reineke/indent-blankline.nvim",
    main = "ibl",
    event = { "BufReadPost", "BufNewFile" },
    opts = {},
  },
  {
    "windwp/nvim-autopairs",
    event = "InsertEnter",
    opts = {},
  },
  {
    "numToStr/Comment.nvim",
    keys = {
      { "gc", mode = { "n", "v" }, desc = "Comment toggle linewise" },
      { "gb", mode = { "n", "v" }, desc = "Comment toggle blockwise" },
    },
    opts = {},
  },
  {
    "folke/which-key.nvim",
    event = "VeryLazy",
    opts = {},
  },
  {
    "folke/trouble.nvim",
    dependencies = { "nvim-tree/nvim-web-devicons" },
    cmd = "Trouble",
    keys = {
      { "<leader>xx", "<cmd>Trouble diagnostics toggle<cr>", desc = "Diagnostics (Trouble)" },
    },
    opts = {},
  },
  {
    "folke/tokyonight.nvim",
    lazy = false,
    priority = 1000,
    config = function()
      -- transparent = true, plus the two "transparent" styles below, clear
      -- bg on Normal/NormalFloat/SignColumn/EndOfBuffer AND on the groups
      -- tokyonight ships dedicated support for: nvim-tree, telescope,
      -- bufferline, which-key, trouble. That covers every UI surface this
      -- config uses except nvim-cmp's popup menu, which tokyonight doesn't
      -- treat as a float -- Pmenu is cleared by hand just below for that.
      require("tokyonight").setup({
        style = "storm",
        transparent = true,
        styles = {
          sidebars = "transparent",
          floats = "transparent",
        },
      })
      vim.cmd.colorscheme("tokyonight")

      -- Re-applied on every colorscheme (re)load, not just this one, so a
      -- manual `:colorscheme tokyonight` later doesn't quietly undo it.
      vim.api.nvim_create_autocmd("ColorScheme", {
        group = vim.api.nvim_create_augroup("DevEnvTransparency", { clear = true }),
        callback = function()
          -- PmenuSel is left alone on purpose: that's the selected-item
          -- highlight, not a background, and needs to stay visible.
          vim.api.nvim_set_hl(0, "Pmenu", { bg = "NONE" })
        end,
      })
      vim.api.nvim_set_hl(0, "Pmenu", { bg = "NONE" })
    end,
  },
}