-- lang_registry.lua
--
-- Loads registry\languages.json and registry\installed.json -- the SAME
-- files cbr.ps1 / supra.ps1 read. This is the single place Neovim reads
-- or writes that shared state, so every other module (lsp.lua,
-- lang_setup.lua, plugins/init.lua) goes through here.

local M = {}

--- vim.json.decode() turns a JSON `null` into the sentinel vim.NIL, not Lua's
--- own `nil` -- and vim.NIL is truthy, so plain `if entry.lsp then` does NOT
--- do what it looks like it does on a field that's JSON null. Every module
--- reading registry fields that can be null (lsp, mason.*, conform, lint,
--- dap.mason_pkg, run.winget_id, ...) must check through this helper instead
--- of a bare truthiness test.
function M.is_null(v)
  return v == nil or v == vim.NIL
end

--- Inverse convenience: true if v is present and not JSON null.
function M.present(v)
  return not M.is_null(v)
end

-- Overridable via environment variable so this exact file can be tested
-- outside Windows; in normal use these two lines are the only machine-
-- specific paths in the whole Neovim config.
local SCRIPTS_DIR = vim.fn.expand(os.getenv("DEVENV_SCRIPTS_DIR") or "C:\\.scripts\\nvimXpowershell")
M.registry_path = os.getenv("DEVENV_REGISTRY_OVERRIDE") or (SCRIPTS_DIR .. "/registry/languages.json")
M.installed_path = os.getenv("DEVENV_INSTALLED_OVERRIDE") or (SCRIPTS_DIR .. "/registry/installed.json")

local function read_json(path)
  local f = io.open(path, "r")
  if not f then return nil end
  local raw = f:read("*a")
  f:close()
  if not raw or raw == "" then return nil end
  local ok, decoded = pcall(vim.json.decode, raw)
  if not ok then
    vim.notify("lang_registry: failed to parse " .. path .. ": " .. tostring(decoded), vim.log.levels.ERROR)
    return nil
  end
  return decoded
end

local function write_json(path, tbl)
  local ok, encoded = pcall(vim.json.encode, tbl)
  if not ok then
    vim.notify("lang_registry: failed to encode " .. path, vim.log.levels.ERROR)
    return false
  end
  local f = io.open(path, "w")
  if not f then
    vim.notify("lang_registry: could not write " .. path, vim.log.levels.ERROR)
    return false
  end
  f:write(encoded)
  f:close()
  return true
end

local _registry_cache = nil

--- Returns the full languages.json table ({ schema_version, languages = {...} }),
--- loading and caching it on first call. Returns nil if the file is missing or
--- invalid (callers should handle that gracefully -- an editor session
--- shouldn't crash because the registry disappeared).
function M.get_registry()
  if _registry_cache then return _registry_cache end
  local data = read_json(M.registry_path)
  if not data or not data.languages then
    vim.notify(
      "lang_registry: no usable registry at " .. M.registry_path .. ". Dynamic language setup is disabled until it exists.",
      vim.log.levels.WARN
    )
    return nil
  end
  _registry_cache = data
  return _registry_cache
end

--- Re-reads languages.json from disk, discarding the cache. Not needed in
--- normal use (the registry only grows by hand-editing), but handy after
--- editing languages.json in the same Neovim session.
function M.reload_registry()
  _registry_cache = nil
  return M.get_registry()
end

--- Returns the installed-state table ({ installed = {...}, cli_confirmed = {...} }).
--- Always re-read from disk (cheap, and we want to see cbr/supra's updates).
function M.get_installed_state()
  local data = read_json(M.installed_path)
  if not data then
    return { schema_version = 1, installed = {}, cli_confirmed = {}, last_updated = "", history = {} }
  end
  data.installed = data.installed or {}
  data.cli_confirmed = data.cli_confirmed or {}
  return data
end

local function list_contains(list, value)
  for _, v in ipairs(list) do
    if v == value then return true end
  end
  return false
end

--- True if lang_id is in installed.json's "installed" list -- i.e. Neovim has
--- already set up editor tooling (treesitter/LSP/formatter/linter/DAP) for it.
function M.is_installed(lang_id)
  local state = M.get_installed_state()
  return list_contains(state.installed, lang_id)
end

--- Marks lang_id as installed (editor tooling set up). Only lang_setup.lua
--- should call this -- cbr/supra write to the separate 'cli_confirmed' list
--- instead, specifically so a successful terminal compile never tricks
--- Neovim into skipping real editor setup for a language it hasn't touched.
function M.mark_installed(lang_id)
  local state = M.get_installed_state()
  if not list_contains(state.installed, lang_id) then
    table.insert(state.installed, lang_id)
    state.last_updated = os.date("%Y-%m-%dT%H:%M:%S")
    write_json(M.installed_path, state)
  end
end

--- Returns { id = ..., entry = ... } for the language whose filetypes list
--- contains ft, or nil if the registry has no such language.
function M.get_by_filetype(ft)
  local registry = M.get_registry()
  if not registry then return nil end
  for id, entry in pairs(registry.languages) do
    if entry.filetypes then
      for _, t in ipairs(entry.filetypes) do
        if t == ft then return { id = id, entry = entry } end
      end
    end
  end
  return nil
end

--- All language ids in the registry marked "default": true -- the first-time
--- setup set.
function M.get_default_lang_ids()
  local registry = M.get_registry()
  if not registry then return {} end
  local ids = {}
  for id, entry in pairs(registry.languages) do
    if entry.default then table.insert(ids, id) end
  end
  table.sort(ids)
  return ids
end

--- All language ids currently marked installed in installed.json, intersected
--- with what the registry actually still defines (so a stale id left over
--- from an edited-out registry entry can't break anything downstream).
function M.get_installed_lang_ids()
  local registry = M.get_registry()
  if not registry then return {} end
  local state = M.get_installed_state()
  local ids = {}
  for _, id in ipairs(state.installed) do
    if registry.languages[id] then table.insert(ids, id) end
  end
  table.sort(ids)
  return ids
end

return M