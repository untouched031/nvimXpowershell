-- dap_config.lua
--
-- Two debugger paths, chosen per-language by registry/languages.json's
-- "dap.kind" field:
--   "gdb"   -- a hand-written adapter using the gdb that already ships with
--             the MSYS2 ucrt64 toolchain (setup guide Step-03). No extra
--             download needed, so this is used for C/C++ rather than
--             pulling in Mason's much larger codelldb for a toolchain
--             that's already on PATH.
--   "mason" -- everything else. mason-nvim-dap.nvim (configured in
--             plugins/init.lua) auto-generates a sane adapter + launch
--             config the moment the named Mason debug-adapter package is
--             installed, so there is nothing to hand-write here at all.
-- "none" languages just don't get a debugger.

local M = {}
local registry = require("lang_registry")

local _gdb_adapter_defined = false

local function ensure_gdb_adapter()
  if _gdb_adapter_defined then return end
  _gdb_adapter_defined = true
  local ok, dap = pcall(require, "dap")
  if not ok then return end

  dap.adapters.gdb = {
    type = "executable",
    command = "gdb",
    args = { "-i", "dap" },
  }
end

--- Registers a dap.configurations[filetype] entry for one "gdb"-kind
--- language. Safe to call more than once for the same language.
function M.setup_for_lang(lang_id)
  local reg = registry.get_registry()
  if not reg or not reg.languages[lang_id] then return end
  local entry = reg.languages[lang_id]
  if registry.is_null(entry.dap) or entry.dap.kind ~= "gdb" then return end

  local ok, dap = pcall(require, "dap")
  if not ok then return end
  ensure_gdb_adapter()

  for _, ft in ipairs(entry.filetypes) do
    dap.configurations[ft] = dap.configurations[ft] or {}
    local already = false
    for _, c in ipairs(dap.configurations[ft]) do
      if c.name == (entry.label .. ": launch") then already = true end
    end
    if not already then
      table.insert(dap.configurations[ft], {
        name = entry.label .. ": launch",
        type = "gdb",
        request = "launch",
        program = function()
          return vim.fn.input("Path to executable: ", vim.fn.getcwd() .. "/", "file")
        end,
        cwd = "${workspaceFolder}",
        stopAtBeginningOfMainSubprogram = false,
      })
    end
  end
end

--- Call once at startup for every already-installed "gdb"-kind language.
function M.setup()
  for _, lang_id in ipairs(registry.get_installed_lang_ids()) do
    M.setup_for_lang(lang_id)
  end

  local ok, dap = pcall(require, "dap")
  if not ok then return end
  local dapui_ok, dapui = pcall(require, "dapui")

  local map = vim.keymap.set
  map("n", "<F5>", dap.continue, { desc = "DAP: Continue / Start" })
  map("n", "<F9>", dap.toggle_breakpoint, { desc = "DAP: Toggle breakpoint" })
  map("n", "<F10>", dap.step_over, { desc = "DAP: Step over" })
  map("n", "<F11>", dap.step_into, { desc = "DAP: Step into" })
  map("n", "<F12>", dap.step_out, { desc = "DAP: Step out" })
  map("n", "<leader>dr", dap.repl.toggle, { desc = "DAP: Toggle REPL" })
  map("n", "<leader>db", dap.toggle_breakpoint, { desc = "DAP: Toggle breakpoint" })
  map("n", "<leader>dc", dap.continue, { desc = "DAP: Continue" })
  map("n", "<leader>dt", dap.terminate, { desc = "DAP: Terminate" })
  if dapui_ok then
    map("n", "<leader>du", dapui.toggle, { desc = "DAP: Toggle UI" })
    dap.listeners.after.event_initialized["dapui_config"] = function() dapui.open() end
    dap.listeners.before.event_terminated["dapui_config"] = function() dapui.close() end
    dap.listeners.before.event_exited["dapui_config"] = function() dapui.close() end
  end
end

return M