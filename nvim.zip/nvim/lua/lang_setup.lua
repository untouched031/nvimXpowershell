-- lang_setup.lua
--
-- The dynamic engine. One autocmd, one job: the first time a filetype with
-- a registry entry is opened and that language isn't marked installed yet,
-- install everything it needs (treesitter parser, LSP server, formatter,
-- linter, debug adapter) and mark it installed so this never repeats. The
-- defaults from first-time setup skip straight past all of this because
-- registry.is_installed() is already true for them.

local M = {}
local registry = require("lang_registry")
local lsp_mod = require("lsp")
local dap_config = require("dap_config")

--- Toggle if you'd rather be asked before winget runs. Default is "just do
--- it" to match "everything required will be auto setup" -- cbr.ps1 will
--- still ask interactively if you end up installing a toolchain from the
--- terminal instead.
M.auto_install_system_tools = true

local _in_progress = {} -- lang_id -> true, prevents duplicate concurrent triggers
local _warned_unknown_ft = {} -- ft -> true, so the "not in registry" notice only shows once per filetype

-- -----------------------------------------------------------------------
-- Mason package installs, with real completion callbacks (not fire-and-
-- forget Ex commands) so we know exactly when it's safe to enable the LSP
-- client / mark the language installed.
-- -----------------------------------------------------------------------

--- Resolves an lspconfig server name (e.g. "clangd") to the Mason package
--- that provides it (e.g. "clangd" -- usually but not always the same
--- string), using mason-lspconfig's own live mapping rather than a name we
--- hardcoded, so it stays correct even if a package gets renamed upstream.
local function lspconfig_name_to_mason_pkg(server_name)
  local ok, mappings = pcall(require, "mason-lspconfig.mappings")
  if not ok then return server_name end
  local ok2, map = pcall(mappings.get_mason_map)
  if not ok2 or not map.lspconfig_to_package[server_name] then
    return server_name -- best-effort fallback: many names match 1:1 anyway
  end
  return map.lspconfig_to_package[server_name]
end

--- Installs every named Mason package (skipping ones already installed),
--- then calls on_done(all_ok). Never throws even if mason.nvim isn't
--- available or a package name turns out to be wrong -- it reports and
--- moves on rather than leaving the caller hanging.
local function mason_install_many(pkg_names, on_done)
  pkg_names = vim.tbl_filter(function(n) return registry.present(n) and n ~= "" end, pkg_names)
  if #pkg_names == 0 then
    on_done(true)
    return
  end

  local ok, mr = pcall(require, "mason-registry")
  if not ok then
    vim.notify("lang_setup: mason-registry.nvim isn't available; skipping tool install.", vim.log.levels.WARN)
    on_done(false)
    return
  end

  local function do_installs()
    local to_install = {}
    local any_missing = false
    for _, name in ipairs(pkg_names) do
      local pok, pkg = pcall(mr.get_package, name)
      if not pok then
        any_missing = true
        vim.schedule(function()
          vim.notify(
            "lang_setup: Mason has no package named '" .. name .. "'. Fix this in registry\\languages.json.",
            vim.log.levels.WARN
          )
        end)
      elseif not pkg:is_installed() and not pkg:is_installing() then
        table.insert(to_install, pkg)
      end
    end

    if #to_install == 0 then
      on_done(not any_missing)
      return
    end

    local remaining = #to_install
    local all_ok = not any_missing

    local function finish_one(ok_result)
      if not ok_result then all_ok = false end
      remaining = remaining - 1
      if remaining <= 0 then
        vim.schedule(function() on_done(all_ok) end)
      end
    end

    -- Retries, async (no vim.wait -- this runs during interactive editing
    -- and must not freeze the UI). An install failing once isn't
    -- necessarily final: a transient error has no fingerprint to clean up
    -- but can still succeed on a plain retry, and a package left in a
    -- "<path> is already linked" state by an earlier killed install (e.g.
    -- Neovim closed mid-install) needs that exact stale file removed first,
    -- which the failing install's own error message names. A package with
    -- many files can need more than one or two passes (jdtls alone bundles
    -- dozens of plugin jars, each only revealed as the next retry's error),
    -- hence 10 attempts rather than 2 or 3.
    local MAX_ATTEMPTS = 10
    local function install_with_retry(pkg, attempt)
      attempt = attempt or 1
      local pkg_ok, err = pcall(function()
        pkg:install({}, function(success, result)
          if success then
            finish_one(true)
            return
          end
          if attempt >= MAX_ATTEMPTS then
            vim.schedule(function()
              vim.notify("lang_setup: install failed for '" .. pkg.name .. "': " .. vim.inspect(result), vim.log.levels.WARN)
            end)
            finish_one(false)
            return
          end
          local function retry() install_with_retry(pkg, attempt + 1) end
          if pkg:is_installed() then
            local uok = pcall(function() pkg:uninstall({}, retry) end)
            if not uok then retry() end
          else
            local msg = type(result) == "string" and result or vim.inspect(result)
            local stale_link = msg:match('"([^"]-)"%s+is already linked')
            if stale_link then pcall(vim.fn.delete, stale_link) end
            retry()
          end
        end)
      end)
      if not pkg_ok then
        vim.schedule(function()
          vim.notify("lang_setup: could not start install for '" .. pkg.name .. "': " .. tostring(err), vim.log.levels.WARN)
        end)
        finish_one(false)
      end
    end

    for _, pkg in ipairs(to_install) do
      install_with_retry(pkg)
    end
  end

  -- Registry needs at least one successful refresh before package lookups
  -- work; mason.nvim does this on startup too, so this is usually instant.
  if mr.refresh then
    local ok_refresh = pcall(mr.refresh, do_installs)
    if not ok_refresh then do_installs() end
  else
    do_installs()
  end
end

-- -----------------------------------------------------------------------
-- System compiler / runtime check (gcc, python, node, go, ...) -- things
-- Mason does not and should not provide. Separate from the Mason install
-- above because cbr.ps1 also does this same check independently; this is
-- just "try to save the person a trip to the terminal."
-- -----------------------------------------------------------------------

local _tool_check_done = {}

local function check_system_tool(entry)
  local run = entry.run
  if registry.is_null(run) or registry.is_null(run.check_cmd) or run.check_cmd == "" then return end
  if _tool_check_done[run.check_cmd] then return end
  _tool_check_done[run.check_cmd] = true

  if vim.fn.executable(run.check_cmd) == 1 then return end

  local hint = registry.present(run.install_hint) and run.install_hint or ("Install " .. entry.label .. "'s compiler/runtime.")
  if registry.present(run.winget_id) and M.auto_install_system_tools and vim.fn.executable("winget") == 1 then
    vim.notify(entry.label .. "'s compiler/runtime (" .. run.check_cmd .. ") isn't on PATH. Installing with winget in the background: " .. run.winget_id, vim.log.levels.INFO)
    vim.system(
      { "winget", "install", "-e", "--id", run.winget_id, "--silent", "--accept-package-agreements", "--accept-source-agreements" },
      { text = true },
      function(obj)
        vim.schedule(function()
          if obj.code == 0 then
            vim.notify(entry.label .. ": winget install finished. Open a NEW terminal/Neovim so PATH picks it up.", vim.log.levels.INFO)
          else
            vim.notify(entry.label .. ": winget install exited with code " .. obj.code .. ". " .. hint, vim.log.levels.WARN)
          end
        end)
      end
    )
  else
    vim.notify(entry.label .. "'s compiler/runtime (" .. run.check_cmd .. ") isn't on PATH yet.\n" .. hint, vim.log.levels.WARN)
  end
end

-- -----------------------------------------------------------------------
-- Formatter / linter wiring. conform.nvim and nvim-lint both expose plain,
-- directly-mutable Lua tables for this, so no re-setup() call is needed --
-- we just add the new filetype's entry to the table that's already live.
-- -----------------------------------------------------------------------

local function wire_formatter(lang_id, entry)
  if registry.is_null(entry.conform) or entry.conform == "" then return end
  local ok, conform = pcall(require, "conform")
  if not ok then return end
  conform.formatters_by_ft = conform.formatters_by_ft or {}
  for _, ft in ipairs(entry.filetypes) do
    conform.formatters_by_ft[ft] = { entry.conform }
  end
end

local function wire_linter(lang_id, entry)
  if registry.is_null(entry.lint) or entry.lint == "" then return end
  local ok, lint = pcall(require, "lint")
  if not ok then return end
  lint.linters_by_ft = lint.linters_by_ft or {}
  for _, ft in ipairs(entry.filetypes) do
    lint.linters_by_ft[ft] = { entry.lint }
  end
end

-- -----------------------------------------------------------------------
-- The orchestrator for one language.
-- -----------------------------------------------------------------------

--- Installs everything registry/languages.json says lang_id needs, then
--- marks it installed. Safe to call for an already-installed language
--- (no-ops immediately) or call twice concurrently (second call is ignored
--- while the first is still running).
function M.setup_language(lang_id, opts)
  opts = opts or {}
  local reg = registry.get_registry()
  if not reg or not reg.languages[lang_id] then return end
  if registry.is_installed(lang_id) and not opts.force then return end
  if _in_progress[lang_id] then return end
  _in_progress[lang_id] = true

  local entry = reg.languages[lang_id]
  if not opts.silent then
    vim.notify("Setting up " .. entry.label .. " support for the first time...", vim.log.levels.INFO)
  end

  -- Treesitter: fire-and-forget, :TSInstall is its own async job and a
  -- missing/renamed parser is cosmetic (falls back to no highlighting),
  -- not worth blocking the rest of setup over.
  if entry.treesitter and #entry.treesitter > 0 then
    local ok, err = pcall(vim.cmd, "TSInstall " .. table.concat(entry.treesitter, " "))
    if not ok then
      vim.notify("lang_setup: TSInstall failed for " .. entry.label .. ": " .. tostring(err), vim.log.levels.WARN)
    end
  end

  check_system_tool(entry)

  local mason_pkgs = {}
  if registry.present(entry.lsp) and registry.present(entry.lsp.server) then
    table.insert(mason_pkgs, lspconfig_name_to_mason_pkg(entry.lsp.server))
  end
  if registry.present(entry.mason) then
    if registry.present(entry.mason.formatter) then table.insert(mason_pkgs, entry.mason.formatter) end
    if registry.present(entry.mason.linter) then table.insert(mason_pkgs, entry.mason.linter) end
  end
  if registry.present(entry.dap) and entry.dap.kind == "mason" and registry.present(entry.dap.mason_pkg) then
    table.insert(mason_pkgs, entry.dap.mason_pkg)
  end

  mason_install_many(mason_pkgs, function(all_ok)
    if registry.present(entry.lsp) then
      lsp_mod.enable_for_lang(lang_id)
    end
    wire_formatter(lang_id, entry)
    wire_linter(lang_id, entry)
    if registry.present(entry.dap) and entry.dap.kind == "gdb" then
      dap_config.setup_for_lang(lang_id)
    end
    -- mason-nvim-dap's own automatic_installation handler picks up "mason"
    -- kind debug adapters as soon as they're installed above; nothing else
    -- to wire by hand for those.

    registry.mark_installed(lang_id)
    _in_progress[lang_id] = false

    if not opts.silent then
      if all_ok then
        vim.notify(entry.label .. " is ready: highlighting, intellisense, formatting and (where available) debugging are set up.", vim.log.levels.INFO)
      else
        vim.notify(entry.label .. " is partially set up -- see the warning(s) above for what to fix in registry\\languages.json.", vim.log.levels.WARN)
      end
    end
  end)
end

-- -----------------------------------------------------------------------
-- Autocmds
-- -----------------------------------------------------------------------

function M.setup()
  -- Generic treesitter highlighting for literally any filetype that has a
  -- parser installed -- no pattern list to maintain. vim.treesitter.start
  -- itself no-ops (via pcall) when there's no parser for the filetype yet.
  vim.api.nvim_create_autocmd("FileType", {
    group = vim.api.nvim_create_augroup("DevEnvTreesitterStart", { clear = true }),
    pattern = "*",
    callback = function(ev)
      pcall(vim.treesitter.start, ev.buf)
    end,
  })

  vim.api.nvim_create_autocmd("FileType", {
    group = vim.api.nvim_create_augroup("DevEnvLangSetup", { clear = true }),
    pattern = "*",
    callback = function(ev)
      local ft = ev.match
      if ft == "" then return end
      -- Skip Neovim's own internal buffers (checkhealth, help, Lazy, Mason,
      -- Telescope, NvimTree, DAP's own windows, ...) -- all of these use a
      -- non-empty buftype, where a real source file is always "". Without
      -- this, e.g. opening :checkhealth triggers the "unknown filetype"
      -- notice below for the "checkhealth" pseudo-filetype.
      if vim.bo[ev.buf].buftype ~= "" then return end
      local found = registry.get_by_filetype(ft)
      if not found then
        if not _warned_unknown_ft[ft] then
          _warned_unknown_ft[ft] = true
          vim.notify(
            "No registry entry for filetype '" .. ft .. "' yet -- syntax highlighting may still work, "
            .. "but intellisense/compile/debug need an entry added to registry\\languages.json.",
            vim.log.levels.INFO
          )
        end
        return
      end
      M.setup_language(found.id)
    end,
  })
end

return M