-- keymaps.lua
--
-- Non-language-tooling keymaps: window/buffer navigation and the cbr/supra
-- terminal integration. LSP keymaps live in lsp.lua's on_attach (they only
-- make sense once a server has attached); debugger keymaps live in
-- dap_config.lua (the original config set F5/F9-F12 in both this file AND
-- dap_config.lua, which worked only because dap_config.lua happened to
-- load second and silently won the conflict -- one home for them now).

local map = vim.keymap.set

map("n", "<C-h>", "<C-w>h", { desc = "Window left" })
map("n", "<C-j>", "<C-w>j", { desc = "Window down" })
map("n", "<C-k>", "<C-w>k", { desc = "Window up" })
map("n", "<C-l>", "<C-w>l", { desc = "Window right" })

map("n", "<S-h>", "<cmd>bprevious<cr>", { desc = "Previous buffer" })
map("n", "<S-l>", "<cmd>bnext<cr>", { desc = "Next buffer" })
map("n", "<leader>bd", "<cmd>bdelete<cr>", { desc = "Delete buffer" })

map("n", "<leader>w", "<cmd>w<cr>", { desc = "Save" })
map("n", "<leader>q", "<cmd>q<cr>", { desc = "Quit" })

map("v", "<", "<gv", { desc = "Indent left (stay selected)" })
map("v", ">", ">gv", { desc = "Indent right (stay selected)" })
map("v", "J", ":m '>+1<CR>gv=gv", { desc = "Move selection down" })
map("v", "K", ":m '<-2<CR>gv=gv", { desc = "Move selection up" })

-- ---------------------------------------------------------------------
-- cbr / supra integration. Both are PowerShell functions defined in
-- C:\.scripts\nvimXpowershell\{cbr,supra}.ps1 and sourced from $PROFILE,
-- so running pwsh WITHOUT -NoProfile is what makes them available here.
-- They stay plain terminal commands rather than something reimplemented
-- in Lua, so "what cbr does" only has to be correct in one place.
-- ---------------------------------------------------------------------

local function run_in_pwsh_terminal(cmd)
  local ok, Terminal = pcall(function() return require("toggleterm.terminal").Terminal end)
  if ok then
    Terminal:new({
      cmd = "pwsh -NoLogo -Command " .. vim.fn.shellescape(cmd),
      direction = "float",
      close_on_exit = false,
    }):toggle()
  else
    vim.cmd("vsplit | terminal pwsh -NoLogo -Command " .. vim.fn.shellescape(cmd))
  end
end

map("n", "<F7>", function()
  vim.cmd("silent! update")
  local file = vim.fn.expand("%:p")
  run_in_pwsh_terminal("cbr '" .. file .. "'")
end, { desc = "cbr: compile + build + run current file" })

map("n", "<leader>cs", function()
  local dir = vim.fn.expand("%:p:h")
  run_in_pwsh_terminal("supra '" .. dir .. "'")
end, { desc = "supra: scan current file's folder" })

map("n", "<leader>cS", function()
  run_in_pwsh_terminal("supra '" .. vim.fn.getcwd() .. "'")
end, { desc = "supra: scan whole project (cwd)" })