-- lsp.lua
--
-- Data-driven LSP setup. Every server's filetypes/settings come from
-- registry/languages.json via lang_registry.lua -- there is no per-language
-- vim.lsp.config() block to hand-write anymore. Adding a language to the
-- JSON (or on-demand install via lang_setup.lua) is enough for it to get
-- intellisense; this file never needs to change for that.

local M = {}
local registry = require("lang_registry")

-- ---------------------------------------------------------------------
-- Shared capabilities + on_attach, identical for every server.
-- ---------------------------------------------------------------------

local function make_capabilities()
  local capabilities = vim.lsp.protocol.make_client_capabilities()
  local ok, cmp_lsp = pcall(require, "cmp_nvim_lsp")
  if ok then
    capabilities = cmp_lsp.default_capabilities(capabilities)
  end
  return capabilities
end

local capabilities = make_capabilities()

local function on_attach(_, bufnr)
  local opts = { buffer = bufnr, silent = true }
  local map = vim.keymap.set

  map("n", "gd", vim.lsp.buf.definition, vim.tbl_extend("force", opts, { desc = "Go to definition" }))
  map("n", "gD", vim.lsp.buf.declaration, vim.tbl_extend("force", opts, { desc = "Go to declaration" }))
  map("n", "gi", vim.lsp.buf.implementation, vim.tbl_extend("force", opts, { desc = "Go to implementation" }))
  map("n", "gr", vim.lsp.buf.references, vim.tbl_extend("force", opts, { desc = "References" }))
  map("n", "K", vim.lsp.buf.hover, vim.tbl_extend("force", opts, { desc = "Hover docs" }))
  map("n", "<C-k>", vim.lsp.buf.signature_help, vim.tbl_extend("force", opts, { desc = "Signature help" }))
  map("n", "<leader>rn", vim.lsp.buf.rename, vim.tbl_extend("force", opts, { desc = "Rename symbol" }))
  map({ "n", "v" }, "<leader>ca", vim.lsp.buf.code_action, vim.tbl_extend("force", opts, { desc = "Code action" }))
  map("n", "<leader>D", vim.lsp.buf.type_definition, vim.tbl_extend("force", opts, { desc = "Type definition" }))
  map("n", "<leader>f", function() vim.lsp.buf.format({ async = true }) end, vim.tbl_extend("force", opts, { desc = "Format buffer" }))
  map("n", "[d", vim.diagnostic.goto_prev, vim.tbl_extend("force", opts, { desc = "Prev diagnostic" }))
  map("n", "]d", vim.diagnostic.goto_next, vim.tbl_extend("force", opts, { desc = "Next diagnostic" }))
  map("n", "<leader>e", vim.diagnostic.open_float, vim.tbl_extend("force", opts, { desc = "Line diagnostics" }))
  map("n", "<leader>q", vim.diagnostic.setloclist, vim.tbl_extend("force", opts, { desc = "Diagnostics to loclist" }))
end

vim.diagnostic.config({
  virtual_text = { prefix = "●", spacing = 2 },
  signs = true,
  underline = true,
  update_in_insert = false,
  severity_sort = true,
  float = { border = "rounded", source = true },
})

do
  local signs = { Error = "✘", Warn = "▲", Hint = "⚑", Info = "ℹ" }
  for type, icon in pairs(signs) do
    local hl = "DiagnosticSign" .. type
    vim.fn.sign_define(hl, { text = icon, texthl = hl, numhl = "" })
  end
end

-- ---------------------------------------------------------------------
-- Register every server the registry knows about. vim.lsp.config() only
-- REGISTERS a config; it does not start anything, so registering all of
-- them up front (even ones not yet "installed") is cheap and harmless --
-- it just means vim.lsp.enable() later is a one-line call with nothing
-- else to configure.
-- ---------------------------------------------------------------------

--- Per-server settings that need something beyond what the registry alone
--- can express cleanly (workspace libraries, schema URLs, etc). Keyed by
--- lspconfig server name. Anything not listed here just uses the plain
--- settings object from the registry entry (usually {}).
local EXTRA_SETTINGS = {
  lua_ls = {
    Lua = {
      diagnostics = { globals = { "vim" } },
      workspace = {
        library = vim.api.nvim_get_runtime_file("", true),
        checkThirdParty = false,
      },
      telemetry = { enable = false },
    },
  },
  jsonls = {
    json = {
      validate = { enable = true },
    },
  },
  pyright = {
    python = {
      analysis = { typeCheckingMode = "basic", autoSearchPaths = true, useLibraryCodeForTypes = true },
    },
  },
}

local _configured_servers = {} -- server_name -> true, so we only vim.lsp.config() each once
local _server_to_langs = {}    -- server_name -> { lang_id, ... }, for diagnostics/troubleshooting

function M.configure_all_servers()
  local reg = registry.get_registry()
  if not reg then return end

  for lang_id, entry in pairs(reg.languages) do
    if registry.present(entry.lsp) and registry.present(entry.lsp.server) then
      local server = entry.lsp.server
      _server_to_langs[server] = _server_to_langs[server] or {}
      table.insert(_server_to_langs[server], lang_id)

      if not _configured_servers[server] then
        _configured_servers[server] = true
        local settings = EXTRA_SETTINGS[server] or entry.lsp.settings or {}
        local filetypes = entry.lsp.filetypes or entry.filetypes

        local ok, err = pcall(vim.lsp.config, server, {
          capabilities = capabilities,
          on_attach = on_attach,
          filetypes = filetypes,
          settings = settings,
        })
        if not ok then
          vim.notify("lsp.lua: vim.lsp.config('" .. server .. "') failed: " .. tostring(err), vim.log.levels.WARN)
        end
      end
    end
  end
end

local _enabled_servers = {}

--- Enables (starts auto-attaching) the LSP server for one installed language.
--- Safe to call more than once for the same language -- subsequent calls
--- are no-ops. lang_setup.lua calls this right after a new language's
--- server finishes installing via Mason.
function M.enable_for_lang(lang_id)
  local reg = registry.get_registry()
  if not reg or not reg.languages[lang_id] then return end
  local entry = reg.languages[lang_id]
  if registry.is_null(entry.lsp) or registry.is_null(entry.lsp.server) then return end
  local server = entry.lsp.server
  if _enabled_servers[server] then return end
  _enabled_servers[server] = true
  local ok, err = pcall(vim.lsp.enable, server)
  if not ok then
    vim.notify("lsp.lua: vim.lsp.enable('" .. server .. "') failed: " .. tostring(err), vim.log.levels.WARN)
  end
end

--- Call once at startup: configures every known server, then enables the
--- ones belonging to already-installed languages.
function M.setup()
  M.configure_all_servers()
  for _, lang_id in ipairs(registry.get_installed_lang_ids()) do
    M.enable_for_lang(lang_id)
  end
end

return M