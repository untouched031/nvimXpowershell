-- init.lua
--
-- Load order matters here:
--   1. options        -- plain vim.opt, no dependencies
--   2. keymaps         -- non-plugin keymaps (cbr/supra, window nav, etc.)
--   3. lazy.nvim bootstrap + plugin load -- this is what pulls in
--      treesitter/mason/lspconfig/conform/nvim-lint/dap and, through
--      plugins/init.lua's config functions, calls lsp.lua's setup()
--      and dap_config.lua's setup()
--   4. lang_setup       -- registers the FileType autocmd that makes new
--      languages set themselves up on first open. Loaded last and on
--      purpose: everything it can call into (lsp.lua, dap_config.lua,
--      conform, nvim-lint, mason) needs to already exist.

require("options")
require("keymaps")

local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
  vim.fn.system({
    "git", "clone", "--filter=blob:none",
    "https://github.com/folke/lazy.nvim.git",
    "--branch=stable",
    lazypath,
  })
end
vim.opt.rtp:prepend(lazypath)

require("lazy").setup("plugins", {
  install = { colorscheme = { "tokyonight", "habamax" } },
  checker = { enabled = false },
})

require("lang_setup").setup()