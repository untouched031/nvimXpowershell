# =====================================================================
#  devenv-lib.ps1
#  Shared library for cbr.ps1 and supra.ps1.
#
#  Both scripts dot-source this file and then read the SAME
#  languages.json / installed.json that Neovim's lang_setup.lua
#  writes to. Neither cbr nor supra hard-codes a single language:
#  add an entry to languages.json and both scripts gain it instantly.
# =====================================================================

$script:DevEnvRoot     = Split-Path -Parent $PSCommandPath
$script:RegistryPath   = Join-Path $DevEnvRoot "registry\languages.json"
$script:InstalledPath  = Join-Path $DevEnvRoot "registry\installed.json"
$script:_RegistryCache = $null

function Get-LangRegistry {
    <# Loads (and caches for this process) languages.json as a PowerShell object. #>
    if ($null -ne $script:_RegistryCache) { return $script:_RegistryCache }
    if (-not (Test-Path -LiteralPath $script:RegistryPath)) {
        Write-Host ""
        Write-Host "  Registry not found: $script:RegistryPath" -ForegroundColor Red
        Write-Host "  Re-run the setup steps that create registry\languages.json." -ForegroundColor Yellow
        Write-Host ""
        return $null
    }
    try {
        $raw = Get-Content -LiteralPath $script:RegistryPath -Raw -ErrorAction Stop
        $script:_RegistryCache = $raw | ConvertFrom-Json -ErrorAction Stop
        return $script:_RegistryCache
    } catch {
        Write-Host ""
        Write-Host "  Could not parse $script:RegistryPath" -ForegroundColor Red
        Write-Host "  $($_.Exception.Message)" -ForegroundColor Yellow
        Write-Host ""
        return $null
    }
}

function Get-InstalledState {
    if (-not (Test-Path -LiteralPath $script:InstalledPath)) {
        return [pscustomobject]@{ schema_version = 1; installed = @(); cli_confirmed = @(); last_updated = ""; history = @{} }
    }
    try {
        $state = Get-Content -LiteralPath $script:InstalledPath -Raw | ConvertFrom-Json
        if (-not (Get-Member -InputObject $state -Name "cli_confirmed" -ErrorAction SilentlyContinue)) {
            $state | Add-Member -NotePropertyName "cli_confirmed" -NotePropertyValue @()
        }
        return $state
    } catch {
        return [pscustomobject]@{ schema_version = 1; installed = @(); cli_confirmed = @(); last_updated = ""; history = @{} }
    }
}

function Add-CliConfirmedLang {
    <# Records that cbr/supra successfully used this language's compiler or
       runtime from the terminal. Written to 'cli_confirmed', a SEPARATE field
       from 'installed'. 'installed' is Neovim's own record of which languages
       it has set up editor tooling (treesitter/LSP/formatter/DAP) for, and
       only lang_setup.lua writes to it -- cbr/supra must never set a language
       "installed" just because the compiler happened to be on PATH, or Neovim
       would wrongly skip setting up editor tooling for it later. #>
    param([Parameter(Mandatory)][string]$LangId)
    try {
        $state = Get-InstalledState
        $current = @($state.cli_confirmed)
        if ($current -notcontains $LangId) {
            $current += $LangId
            $state.cli_confirmed = $current
            $state.last_updated = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
            ($state | ConvertTo-Json -Depth 10) | Set-Content -LiteralPath $script:InstalledPath -Encoding utf8
        }
    } catch {
        # Non-fatal: cbr/supra still work even if the state file can't be written.
    }
}

function Find-LangEntry {
    <# Resolves a file path to its languages.json entry, or $null if unknown. #>
    param([Parameter(Mandatory)][string]$Path)
    $registry = Get-LangRegistry
    if ($null -eq $registry) { return $null }

    $ext  = [System.IO.Path]::GetExtension($Path)
    $name = [System.IO.Path]::GetFileName($Path)

    foreach ($prop in $registry.languages.PSObject.Properties) {
        $entry = $prop.Value
        if ($entry.extensions -and ($entry.extensions -contains $ext)) {
            return [pscustomobject]@{ Id = $prop.Name; Entry = $entry }
        }
        if ($entry.filenames -and ($entry.filenames -contains $name)) {
            return [pscustomobject]@{ Id = $prop.Name; Entry = $entry }
        }
    }
    return $null
}

function Expand-Template {
    <# Literal (non-regex) {placeholder} substitution -- safe for paths containing
       regex-special or $-prefixed characters. #>
    param(
        [Parameter(Mandatory)][string]$Template,
        [Parameter(Mandatory)][hashtable]$Values
    )
    $result = $Template
    foreach ($key in $Values.Keys) {
        $val = $Values[$key]
        if ($null -eq $val) { $val = "" }
        $result = $result.Replace("{$key}", [string]$val)
    }
    return $result
}

function Test-ToolAvailable {
    param([Parameter(Mandatory)][string]$Command)
    if ([string]::IsNullOrWhiteSpace($Command)) { return $true }
    return [bool](Get-Command $Command -ErrorAction SilentlyContinue)
}

function Request-ToolInstall {
    <# Checks whether $CheckCmd is on PATH; if not, shows the install hint and,
       when a winget id is available, offers to run the install right now. Returns
       $true if the tool is (now) available, $false otherwise. #>
    param(
        [Parameter(Mandatory)][string]$Label,
        [string]$CheckCmd,
        [string]$InstallHint,
        [string]$WingetId
    )
    if (Test-ToolAvailable -Command $CheckCmd) { return $true }

    Write-Host ""
    Write-Host "  $Label isn't on PATH yet." -ForegroundColor Yellow
    if ($InstallHint) { Write-Host "  $InstallHint" -ForegroundColor Gray }

    if ($WingetId -and (Test-ToolAvailable -Command "winget")) {
        $resp = Read-Host "  Install it now with winget? [y/N]"
        if ($resp -match '^(y|yes)$') {
            Write-Host "  Running: winget install -e --id $WingetId --accept-package-agreements --accept-source-agreements" -ForegroundColor DarkGray
            winget install -e --id $WingetId --accept-package-agreements --accept-source-agreements
            Write-Host ""
            Write-Host "  Installed. Open a NEW terminal window so PATH picks it up, then re-run." -ForegroundColor Green
        }
    }
    Write-Host ""
    return $false
}

function Write-DevBanner {
    param([string]$Title, [string]$Color = "Cyan")
    $line = "=" * ([Math]::Max(60, $Title.Length + 4))
    Write-Host ""
    Write-Host $line -ForegroundColor $Color
    Write-Host "  $Title" -ForegroundColor $Color
    Write-Host $line -ForegroundColor $Color
}

function Write-DevFooter {
    param([int]$ExitCode, [double]$Seconds)
    $line = "-" * 60
    Write-Host $line -ForegroundColor DarkGray
    if ($ExitCode -eq 0) {
        Write-Host ("  Done in {0:N2}s  (exit code 0)" -f $Seconds) -ForegroundColor Green
    } else {
        Write-Host ("  Finished in {0:N2}s  (exit code {1})" -f $Seconds, $ExitCode) -ForegroundColor Red
    }
    Write-Host ""
}

function Get-KnownExtensionsSummary {
    $registry = Get-LangRegistry
    if ($null -eq $registry) { return "" }
    $all = foreach ($prop in $registry.languages.PSObject.Properties) { $prop.Value.extensions }
    return ($all | Where-Object { $_ } | Sort-Object -Unique) -join " "
}