-- bootstrap.lua
--
-- Run via: nvim --headless -c "luafile C:\.scripts\nvimXpowershell\bootstrap.lua"
--
-- This is the ONE command that does first-time (and re-verification) setup
-- from PowerShell, with no need to ever sit inside the Neovim UI. Unlike
-- `-c "MasonInstall ..." -c "qa!"`, it BLOCKS on every install -- plugins,
-- Mason packages, treesitter parsers -- until each one actually finishes,
-- so nothing gets killed mid-install. A package left in a broken state by
-- an earlier interrupted run (e.g. a dangling bin symlink, which shows up
-- as "<file> is already linked") is uninstalled and cleanly reinstalled
-- rather than left to fail forever.

local REPORT = {}
local function step(label)
  print("")
  print("==> " .. label)
end
local function ok(msg) print("  [OK]   " .. msg); table.insert(REPORT, { status = "OK", msg = msg }) end
local function warn(msg) print("  [WARN] " .. msg); table.insert(REPORT, { status = "WARN", msg = msg }) end
local function fail(msg) print("  [FAIL] " .. msg); table.insert(REPORT, { status = "FAIL", msg = msg }) end

print("============================================================")
print("  nvimXpowershell bootstrap -- " .. os.date("%Y-%m-%d %H:%M:%S"))
print("============================================================")

-- ---------------------------------------------------------------------
-- 1. Plugins (lazy.nvim)
-- ---------------------------------------------------------------------
step("Syncing plugins")
local lazy_ok, lazy = pcall(require, "lazy")
local manage_ok, manage = pcall(require, "lazy.manage")
if not lazy_ok or not manage_ok then
  fail("require('lazy') / require('lazy.manage') failed -- init.lua did not load lazy.nvim correctly")
  vim.cmd("cquit 1")
end
-- NOTE: install() lives on lazy.manage, not the top-level lazy module.
-- Deliberately install() rather than sync(): install() only clones what's
-- missing (fast when everything's already there -- no per-plugin git
-- remote check), while sync() also checks every plugin for upstream
-- updates, which takes much longer and would update plugins as a side
-- effect of what's supposed to be a "make sure setup is complete" check.
local sok, serr = pcall(function() manage.install({ wait = true, show = false }) end)
if sok then
  ok("lazy.nvim plugins present (" .. #lazy.plugins() .. " total)")
else
  fail("lazy.manage.install failed: " .. tostring(serr))
end

-- ---------------------------------------------------------------------
-- 2. Mason registry refresh (package lookups fail silently without this)
-- ---------------------------------------------------------------------
step("Refreshing the Mason registry")
local mr_ok, mr = pcall(require, "mason-registry")
if not mr_ok then
  fail("require('mason-registry') failed")
  vim.cmd("cquit 1")
end
local refresh_done = false
mr.refresh(function() refresh_done = true end)
vim.wait(30000, function() return refresh_done end, 100)
ok("Mason registry refreshed")

-- ---------------------------------------------------------------------
-- 3. Collect every Mason package + treesitter parser the currently-
--    installed languages need, from the SAME registry.lua cbr/supra read.
-- ---------------------------------------------------------------------
local registry = require("lang_registry")
local reg = registry.get_registry()
if not reg then
  fail("registry\\languages.json did not load -- check the path / JSON syntax")
  vim.cmd("cquit 1")
end

local mappings_ok, mappings = pcall(require, "mason-lspconfig.mappings")
local function lsp_to_mason(server)
  if not mappings_ok then return server end
  local ok2, map = pcall(mappings.get_mason_map)
  if not ok2 or not map.lspconfig_to_package[server] then return server end
  return map.lspconfig_to_package[server]
end

local pkgs, seen = {}, {}
local function add_pkg(name)
  if name and name ~= "" and not seen[name] then
    seen[name] = true
    table.insert(pkgs, name)
  end
end

local parsers, pseen = {}, {}
local lang_ids = registry.get_installed_lang_ids()
for _, lang_id in ipairs(lang_ids) do
  local entry = reg.languages[lang_id]
  if registry.present(entry.lsp) and registry.present(entry.lsp.server) then
    add_pkg(lsp_to_mason(entry.lsp.server))
  end
  if registry.present(entry.mason) then
    if registry.present(entry.mason.formatter) then add_pkg(entry.mason.formatter) end
    if registry.present(entry.mason.linter) then add_pkg(entry.mason.linter) end
  end
  if registry.present(entry.dap) and entry.dap.kind == "mason" and registry.present(entry.dap.mason_pkg) then
    add_pkg(entry.dap.mason_pkg)
  end
  for _, p in ipairs(entry.treesitter or {}) do
    if not pseen[p] then
      pseen[p] = true
      table.insert(parsers, p)
    end
  end
end
table.sort(pkgs)
table.sort(parsers)
print("  " .. #lang_ids .. " installed languages -> " .. #pkgs .. " Mason packages, " .. #parsers .. " treesitter parsers")

-- ---------------------------------------------------------------------
-- 4. Install Mason packages. Each install BLOCKS (vim.wait on its own
--    callback) before moving to the next, and anything that fails once
--    gets uninstalled + retried once, which clears exactly the kind of
--    leftover state ("<bin> is already linked") an earlier killed install
--    can leave behind.
-- ---------------------------------------------------------------------
step("Installing Mason packages (this can take a few minutes the first time)")

local function install_blocking(pkg)
  local done, success, result = false, nil, nil
  local iok, ierr = pcall(function()
    pkg:install({}, function(s, r)
      success, result, done = s, r, true
    end)
  end)
  if not iok then
    return false, ierr
  end
  vim.wait(180000, function() return done end, 200)
  if not done then
    return false, "timed out after 180s"
  end
  return success, result
end

--- Best-effort cleanup between retries. If the package currently reports as
--- installed (but install() still just failed -- an inconsistent state),
--- properly uninstall it first via its own async API (callback+wait, same
--- requirement as install). If it does NOT report as installed, a failure
--- that still names a specific "<path> is already linked" file is the
--- fingerprint of an orphaned link from an earlier killed install (e.g. a
--- previous `-c "MasonInstall ..." -c "qa!"` run) -- that exact path is
--- deleted directly. Either way this is opportunistic and safe to call even
--- when neither condition applies; the retry loop below doesn't depend on
--- it returning anything.
local function try_cleanup(pkg, failure_message)
  if pkg:is_installed() then
    local done = false
    local uok = pcall(function()
      pkg:uninstall({}, function() done = true end)
    end)
    if uok then vim.wait(30000, function() return done end, 100) end
    return
  end
  local msg = type(failure_message) == "string" and failure_message or vim.inspect(failure_message)
  local stale_link = msg:match('"([^"]-)"%s+is already linked')
  if stale_link then
    pcall(vim.fn.delete, stale_link)
  end
end

-- Always retries, not just on the "already linked" pattern: a transient
-- failure (a dropped connection mid pip-install, for instance) has no
-- stale-link fingerprint to clean up and would otherwise get zero retries.
-- A package with many files (jdtls bundles dozens of plugin jars) can also
-- need more than one or two passes since each retry clears only the next
-- dangling file the error message names -- 10 is generous without letting
-- a genuinely hopeless package (bad name, no network) hang the whole run.
local MAX_ATTEMPTS = 10

for _, name in ipairs(pkgs) do
  local pok, pkg = pcall(mr.get_package, name)
  if not pok then
    fail(name .. ": no such Mason package -- fix this name in registry\\languages.json")
  elseif pkg:is_installed() then
    ok(name .. " already installed")
  else
    local success, result
    local attempts = 0
    repeat
      success, result = install_blocking(pkg)
      if not success then
        try_cleanup(pkg, result)
        attempts = attempts + 1
      end
    until success or attempts >= MAX_ATTEMPTS
    if success then
      ok(name .. (attempts > 0 and (" installed (after " .. attempts .. " retr" .. (attempts == 1 and "y" or "ies") .. ")") or " installed"))
    else
      fail(name .. ": " .. vim.inspect(result))
    end
  end
end

-- ---------------------------------------------------------------------
-- 5. Treesitter parsers -- also blocking, via the install() handle's
--    own :wait(), not the fire-and-forget :TSInstall command.
-- ---------------------------------------------------------------------
step("Installing treesitter parsers")
local ts_ok, ts = pcall(require, "nvim-treesitter")

local function get_installed_parsers()
  local gok, installed_list = pcall(function() return require('nvim-treesitter.config').get_installed() end)
  local set = {}
  if gok then
    for _, p in ipairs(installed_list) do set[p] = true end
  end
  return set
end

local already_installed = ts_ok and get_installed_parsers() or {}
local missing_parsers = {}
for _, p in ipairs(parsers) do
  if already_installed[p] then
    ok(p .. " parser already installed")
  else
    table.insert(missing_parsers, p)
  end
end
parsers = missing_parsers

if ts_ok and ts.install and #parsers > 0 then
  local still_missing = parsers
  local ts_attempts = 0
  -- A stale per-parser lock from an earlier interrupted run (tree-sitter
  -- CLI's own, held by a PID that no longer exists) can make a build fail
  -- for a reason that has nothing to do with the compiler -- a plain
  -- retry lets its own staleness check reclaim the lock, same spirit as
  -- the Mason retry above. Capped lower than Mason's (3, not 10) since a
  -- persistent failure here is virtually always the compiler itself, which
  -- no amount of retrying fixes.
  repeat
    local iok, handle = pcall(ts.install, still_missing)
    if iok and handle and handle.wait then
      -- handle:wait() not throwing only means the BATCH call didn't error --
      -- a per-parser "tree-sitter build" compile failure is logged and
      -- skipped internally, not raised, so this alone is NOT proof any
      -- parser actually installed (confirmed by deliberately breaking the
      -- compiler and watching wait() still return cleanly). The only
      -- trustworthy check is the real installed-parsers list afterward.
      pcall(function() handle:wait(300000) end)
    else
      fail("Could not start treesitter install: " .. tostring(handle))
      still_missing = {}
    end
    local installed_now = get_installed_parsers()
    local next_missing = {}
    for _, p in ipairs(still_missing) do
      if not installed_now[p] then table.insert(next_missing, p) end
    end
    still_missing = next_missing
    ts_attempts = ts_attempts + 1
  until #still_missing == 0 or ts_attempts >= 3

  local installed_after = get_installed_parsers()
  for _, p in ipairs(parsers) do
    if installed_after[p] then
      ok(p .. " parser installed")
    else
      fail(p .. " parser failed to compile -- see the \"tree-sitter build\" error above (on Windows this is almost always a missing/unconfigured MSVC C compiler, not gcc -- see the note at the end of this report)")
    end
  end
elseif #parsers == 0 then
  ok("No parsers needed")
else
  fail("nvim-treesitter module not available")
end

-- ---------------------------------------------------------------------
-- 6. Summary -- copy/paste this whole block back if anything FAILed.
-- ---------------------------------------------------------------------
step("Summary")
local okc, warnc, failc, ts_failc, py_failc = 0, 0, 0, 0, 0
for _, r in ipairs(REPORT) do
  if r.status == "OK" then okc = okc + 1
  elseif r.status == "WARN" then warnc = warnc + 1
  else
    failc = failc + 1
    if r.msg:match("parser failed to compile") then ts_failc = ts_failc + 1 end
    if r.msg:match("[Ee]xec wrapper for module") then py_failc = py_failc + 1 end
  end
end
print(string.format("  %d OK   %d WARN   %d FAIL", okc, warnc, failc))
if failc > 0 then
  print("")
  print("  Something needs attention -- re-run this script (it's safe to repeat),")
  print("  and if a FAIL above persists, share this whole output.")
end
if ts_failc > 0 then
  print("")
  print("  " .. ts_failc .. " treesitter parser(s) failed to compile. On Windows this is")
  print("  virtually always because the parser build step needs MSVC's cl.exe, not")
  print("  gcc/MinGW -- $env:CC=gcc (correctly) controls what YOUR C/C++ files")
  print("  compile with, but tree-sitter-cli's own build step is a separate tool")
  print("  with its own compiler requirement. Install VS Build Tools (C++ workload)")
  print("  and activate it once per PowerShell session -- see vsdev-env.ps1 -- then")
  print("  re-run this script.")
end
if py_failc > 0 then
  print("")
  print("  " .. py_failc .. " Python-based package failed because pip reported success but the")
  print("  module isn't actually importable afterward in its own venv. On Windows this")
  print("  usually means `python` on PATH isn't the interpreter you think it is (the")
  print("  Microsoft Store's \"python.exe\" app-execution-alias stub is the classic")
  print("  culprit -- it runs, but venvs created from it can silently fail to receive")
  print("  packages). Run: Get-Command python | Format-List Name,Source -- if Source")
  print("  points under WindowsApps, that's it.")
end
print("============================================================")

vim.cmd(failc > 0 and "cquit 1" or "qa!")