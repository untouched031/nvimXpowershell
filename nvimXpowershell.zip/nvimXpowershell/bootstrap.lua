-- bootstrap.lua
--
-- Run via: nvim --headless -c "luafile C:\.scripts\nvimXpowershell\bootstrap.lua"
--
-- This is the ONE command that does first-time (and re-verification) setup
-- from PowerShell, with no need to ever sit inside the Neovim UI. Unlike
-- `-c "MasonInstall ..." -c "qa!"`, it BLOCKS on every install -- plugins,
-- Mason packages, treesitter parsers -- until each one actually finishes,
-- so nothing gets killed mid-install. A package left in a broken state by
-- an earlier interrupted run (e.g. a dangling bin symlink, which shows up
-- as "<file> is already linked") is uninstalled and cleanly reinstalled
-- rather than left to fail forever.

local REPORT = {}
local function step(label)
  print("")
  print("==> " .. label)
end
local function ok(msg) print("  [OK]   " .. msg); table.insert(REPORT, { status = "OK", msg = msg }) end
local function warn(msg) print("  [WARN] " .. msg); table.insert(REPORT, { status = "WARN", msg = msg }) end
local function fail(msg) print("  [FAIL] " .. msg); table.insert(REPORT, { status = "FAIL", msg = msg }) end

print("============================================================")
print("  nvimXpowershell bootstrap -- " .. os.date("%Y-%m-%d %H:%M:%S"))
print("============================================================")

-- ---------------------------------------------------------------------
-- 1. Plugins (lazy.nvim)
-- ---------------------------------------------------------------------
step("Syncing plugins")
local lazy_ok, lazy = pcall(require, "lazy")
local manage_ok, manage = pcall(require, "lazy.manage")
if not lazy_ok or not manage_ok then
  fail("require('lazy') / require('lazy.manage') failed -- init.lua did not load lazy.nvim correctly")
  vim.cmd("cquit 1")
end
-- NOTE: install() lives on lazy.manage, not the top-level lazy module.
-- Deliberately install() rather than sync(): install() only clones what's
-- missing (fast when everything's already there -- no per-plugin git
-- remote check), while sync() also checks every plugin for upstream
-- updates, which takes much longer and would update plugins as a side
-- effect of what's supposed to be a "make sure setup is complete" check.
local sok, serr = pcall(function() manage.install({ wait = true, show = false }) end)
if sok then
  ok("lazy.nvim plugins present (" .. #lazy.plugins() .. " total)")
else
  fail("lazy.manage.install failed: " .. tostring(serr))
end

-- ---------------------------------------------------------------------
-- 2. Mason registry refresh (package lookups fail silently without this)
-- ---------------------------------------------------------------------
step("Refreshing the Mason registry")
local mr_ok, mr = pcall(require, "mason-registry")
if not mr_ok then
  fail("require('mason-registry') failed")
  vim.cmd("cquit 1")
end
local refresh_done = false
mr.refresh(function() refresh_done = true end)
vim.wait(30000, function() return refresh_done end, 100)
ok("Mason registry refreshed")

-- ---------------------------------------------------------------------
-- 3. Collect every Mason package + treesitter parser the currently-
--    installed languages need, from the SAME registry.lua cbr/supra read.
-- ---------------------------------------------------------------------
local registry = require("lang_registry")
local reg = registry.get_registry()
if not reg then
  fail("registry\\languages.json did not load -- check the path / JSON syntax")
  vim.cmd("cquit 1")
end

local mappings_ok, mappings = pcall(require, "mason-lspconfig.mappings")
local function lsp_to_mason(server)
  if not mappings_ok then return server end
  local ok2, map = pcall(mappings.get_mason_map)
  if not ok2 or not map.lspconfig_to_package[server] then return server end
  return map.lspconfig_to_package[server]
end

local pkgs, seen = {}, {}
local function add_pkg(name)
  if name and name ~= "" and not seen[name] then
    seen[name] = true
    table.insert(pkgs, name)
  end
end

local parsers, pseen = {}, {}
local lang_ids = registry.get_installed_lang_ids()
for _, lang_id in ipairs(lang_ids) do
  local entry = reg.languages[lang_id]
  if registry.present(entry.lsp) and registry.present(entry.lsp.server) then
    add_pkg(lsp_to_mason(entry.lsp.server))
  end
  if registry.present(entry.mason) then
    if registry.present(entry.mason.formatter) then add_pkg(entry.mason.formatter) end
    if registry.present(entry.mason.linter) then add_pkg(entry.mason.linter) end
  end
  if registry.present(entry.dap) and entry.dap.kind == "mason" and registry.present(entry.dap.mason_pkg) then
    add_pkg(entry.dap.mason_pkg)
  end
  for _, p in ipairs(entry.treesitter or {}) do
    if not pseen[p] then
      pseen[p] = true
      table.insert(parsers, p)
    end
  end
end
table.sort(pkgs)
table.sort(parsers)
print("  " .. #lang_ids .. " installed languages -> " .. #pkgs .. " Mason packages, " .. #parsers .. " treesitter parsers")

-- ---------------------------------------------------------------------
-- 4. Install Mason packages. Each install BLOCKS (vim.wait on its own
--    callback) before moving to the next, and anything that fails once
--    gets uninstalled + retried once, which clears exactly the kind of
--    leftover state ("<bin> is already linked") an earlier killed install
--    can leave behind.
-- ---------------------------------------------------------------------
step("Installing Mason packages (this can take a few minutes the first time)")

local function install_blocking(pkg)
  local done, success, result = false, nil, nil
  local iok, ierr = pcall(function()
    pkg:install({}, function(s, r)
      success, result, done = s, r, true
    end)
  end)
  if not iok then
    return false, ierr
  end
  vim.wait(180000, function() return done end, 200)
  if not done then
    return false, "timed out after 180s"
  end
  return success, result
end

--- uninstall() is async (needs its own callback+wait, same as install) AND
--- asserts the package currently reports as installed -- so it cannot
--- clean up a package stuck in "not installed, but still has an orphaned
--- bin symlink from an earlier killed install" state, which is exactly
--- what an old `-c "MasonInstall ..." -c "qa!"` run can leave behind. For
--- that case the failing install's own error message names the stale
--- link's exact path, so pull it out of the message and delete it
--- directly instead. A package can have several bin entries (clang-format
--- has three), and each retry only reveals the NEXT dangling one, so this
--- loops rather than cleaning once.
local function cleanup_one_stale_link(pkg, failure_message)
  if pkg:is_installed() then
    local done = false
    local uok = pcall(function()
      pkg:uninstall({}, function() done = true end)
    end)
    if uok then vim.wait(30000, function() return done end, 100) end
    return true
  end
  local msg = type(failure_message) == "string" and failure_message or vim.inspect(failure_message)
  local stale_link = msg:match('"([^"]-)"%s+is already linked')
  if stale_link then
    pcall(vim.fn.delete, stale_link)
    return true
  end
  return false
end

for _, name in ipairs(pkgs) do
  local pok, pkg = pcall(mr.get_package, name)
  if not pok then
    fail(name .. ": no such Mason package -- fix this name in registry\\languages.json")
  elseif pkg:is_installed() then
    ok(name .. " already installed")
  else
    local success, result = install_blocking(pkg)
    local attempts = 0
    while not success and cleanup_one_stale_link(pkg, result) and attempts < 5 do
      attempts = attempts + 1
      success, result = install_blocking(pkg)
    end
    if success then
      ok(name .. (attempts > 0 and (" installed after clearing " .. attempts .. " stale link(s)") or " installed"))
    else
      fail(name .. ": " .. vim.inspect(result))
    end
  end
end

-- ---------------------------------------------------------------------
-- 5. Treesitter parsers -- also blocking, via the install() handle's
--    own :wait(), not the fire-and-forget :TSInstall command.
-- ---------------------------------------------------------------------
step("Installing treesitter parsers")
local ts_ok, ts = pcall(require, "nvim-treesitter")
local already_installed = {}
if ts_ok then
  local gok, installed_list = pcall(function() return require('nvim-treesitter.config').get_installed() end)
  if gok then
    for _, p in ipairs(installed_list) do already_installed[p] = true end
  end
end
local missing_parsers = {}
for _, p in ipairs(parsers) do
  if already_installed[p] then
    ok(p .. " parser already installed")
  else
    table.insert(missing_parsers, p)
  end
end
parsers = missing_parsers
if ts_ok and ts.install and #parsers > 0 then
  local iok, handle = pcall(ts.install, parsers)
  if iok and handle and handle.wait then
    local wok, werr = pcall(function() handle:wait(300000) end)
    if wok then
      ok(#parsers .. " parsers installed")
    else
      warn("Treesitter install did not confirm completion: " .. tostring(werr))
    end
  else
    fail("Could not start treesitter install: " .. tostring(handle))
  end
elseif #parsers == 0 then
  ok("No parsers needed")
else
  fail("nvim-treesitter module not available")
end

-- ---------------------------------------------------------------------
-- 6. Summary -- copy/paste this whole block back if anything FAILed.
-- ---------------------------------------------------------------------
step("Summary")
local okc, warnc, failc = 0, 0, 0
for _, r in ipairs(REPORT) do
  if r.status == "OK" then okc = okc + 1
  elseif r.status == "WARN" then warnc = warnc + 1
  else failc = failc + 1 end
end
print(string.format("  %d OK   %d WARN   %d FAIL", okc, warnc, failc))
if failc > 0 then
  print("")
  print("  Something needs attention -- re-run this script (it's safe to repeat),")
  print("  and if a FAIL above persists, share this whole output.")
end
print("============================================================")

vim.cmd(failc > 0 and "cquit 1" or "qa!")