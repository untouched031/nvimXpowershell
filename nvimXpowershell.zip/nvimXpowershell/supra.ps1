# =====================================================================
#  supra.ps1  --  Project-wide errors / warnings / suggestions, for
#                 whatever languages are found under the scan path.
#
#  Data-driven like cbr: supra has a small, FIXED set of output-format
#  parsers (gcc-style, tsc-style, eslint-JSON, ruff-JSON, javac-style,
#  and a lenient generic "file:line: message" parser). Each language in
#  registry\languages.json just names which parser style its diagnostics
#  command uses. A new language reuses an existing style in almost every
#  case, so most new languages need zero new PowerShell code here too.
# =====================================================================

. (Join-Path (Split-Path -Parent $PSCommandPath) "devenv-lib.ps1")

function _Supra-ParseGcc {
    param([string[]]$Lines, [string]$ScanRoot)
    $items = @()
    $rx = '^(?<file>[^\r\n]+?):(?<line>\d+):(?<col>\d+):\s*(?<sev>fatal error|error|warning|note|remark):\s*(?<msg>.+)$'
    foreach ($ln in $Lines) {
        if ($ln -match $rx) {
            # Capture everything out of $Matches immediately -- anything that does its
            # own regex matching (even `switch -Regex`) silently overwrites $Matches.
            $mFile = $Matches.file
            $mLine = $Matches.line
            $mSev  = $Matches.sev
            $mMsg  = $Matches.msg
            $sev = if ($mSev -eq 'error' -or $mSev -eq 'fatal error') { 'Error' }
                   elseif ($mSev -eq 'warning') { 'Warning' }
                   else { 'Suggestion' }
            $items += [pscustomobject]@{ Severity = $sev; File = $mFile; Line = [int]$mLine; Message = $mMsg }
        }
    }
    return $items
}

function _Supra-ParseTsc {
    param([string[]]$Lines, [string]$ScanRoot)
    $items = @()
    $rx = '^(?<file>[^\r\n(]+)\((?<line>\d+),(?<col>\d+)\):\s*(?<sev>error|warning)\s+(?<code>\S+):\s*(?<msg>.+)$'
    foreach ($ln in $Lines) {
        if ($ln -match $rx) {
            $sev = if ($Matches.sev -eq 'error') { 'Error' } else { 'Warning' }
            $items += [pscustomobject]@{ Severity = $sev; File = $Matches.file; Line = [int]$Matches.line; Message = "$($Matches.code): $($Matches.msg)" }
        }
    }
    return $items
}

function _Supra-ParseJavac {
    param([string[]]$Lines, [string]$ScanRoot)
    $items = @()
    $rx = '^(?<file>[^\r\n]+?):(?<line>\d+):\s*(?<sev>error|warning):\s*(?<msg>.+)$'
    foreach ($ln in $Lines) {
        if ($ln -match $rx) {
            $sev = if ($Matches.sev -eq 'error') { 'Error' } else { 'Warning' }
            $items += [pscustomobject]@{ Severity = $sev; File = $Matches.file; Line = [int]$Matches.line; Message = $Matches.msg }
        }
    }
    return $items
}

function _Supra-ParseGeneric {
    param([string[]]$Lines, [string]$ScanRoot)
    $items = @()
    $rx = '^(?<file>[^\r\n:]+):(?<line>\d+):(?:(?<col>\d+):)?\s*(?<msg>.+)$'
    foreach ($ln in $Lines) {
        if ([string]::IsNullOrWhiteSpace($ln)) { continue }
        if ($ln -match $rx) {
            $items += [pscustomobject]@{ Severity = 'Warning'; File = $Matches.file; Line = [int]$Matches.line; Message = $Matches.msg }
        }
    }
    return $items
}

function _Supra-ParseJsonEslint {
    param([string]$RawJson, [string]$ScanRoot)
    $items = @()
    if ([string]::IsNullOrWhiteSpace($RawJson)) { return $items }
    try { $parsed = $RawJson | ConvertFrom-Json -ErrorAction Stop } catch { return $items }
    foreach ($fileResult in $parsed) {
        foreach ($msg in $fileResult.messages) {
            $sev = if ($msg.severity -eq 2) { 'Error' } else { 'Warning' }
            $ruleTag = if ($msg.ruleId) { "$($msg.ruleId): " } else { "" }
            $items += [pscustomobject]@{ Severity = $sev; File = $fileResult.filePath; Line = [int]($msg.line); Message = "$ruleTag$($msg.message)" }
        }
    }
    return $items
}

function _Supra-ParseRuffJson {
    param([string]$RawJson, [string]$ScanRoot)
    $items = @()
    if ([string]::IsNullOrWhiteSpace($RawJson)) { return $items }
    try { $parsed = $RawJson | ConvertFrom-Json -ErrorAction Stop } catch { return $items }
    foreach ($v in $parsed) {
        $items += [pscustomobject]@{ Severity = 'Warning'; File = $v.filename; Line = [int]($v.location.row); Message = "$($v.code): $($v.message)" }
    }
    return $items
}

function _Supra-RunDiagnostics {
    param($LangEntry, [string]$FilePath, [string]$ScanRoot, [string]$Std, [string[]]$Inc, [switch]$Fast)

    $diag = $LangEntry.diagnostics
    if (-not $diag -or $diag.style -eq 'none' -or -not $diag.cmd) { return @() }
    if (-not (Test-ToolAvailable -Command $diag.check_cmd)) { return @() }

    $effectiveStd = if ($Std) { $Std } elseif ($diag.default_std) { $diag.default_std } else { "" }
    $incFlags = ""
    if ($Inc) { $incFlags = (($Inc | ForEach-Object { "-I `"$_`"" }) -join " ") }

    $values = @{
        file    = $FilePath
        dir     = (Split-Path -Parent $FilePath)
        scandir = $ScanRoot
        std     = $effectiveStd
        inc     = $incFlags
        tempout = [System.IO.Path]::GetTempPath().TrimEnd('\', '/')
        devnull = if ($IsWindows) { "NUL" } else { "/dev/null" }
    }

    $cmd = Expand-Template -Template $diag.cmd -Values $values
    $output = (Invoke-Expression "$cmd 2>&1" | Out-String)

    # @(...) forces array context: PowerShell silently unwraps a 1-element array
    # to a scalar across a function/switch boundary otherwise, which then breaks
    # the += below (a scalar PSObject has no '+' operator).
    $results = @(switch ($diag.style) {
        'gcc'         { _Supra-ParseGcc -Lines ($output -split "`r?`n") -ScanRoot $ScanRoot }
        'tsc'         { _Supra-ParseTsc -Lines ($output -split "`r?`n") -ScanRoot $ScanRoot }
        'javac'       { _Supra-ParseJavac -Lines ($output -split "`r?`n") -ScanRoot $ScanRoot }
        'generic'     { _Supra-ParseGeneric -Lines ($output -split "`r?`n") -ScanRoot $ScanRoot }
        'json_eslint' { _Supra-ParseJsonEslint -RawJson $output -ScanRoot $ScanRoot }
        'ruff_json'   { _Supra-ParseRuffJson -RawJson $output -ScanRoot $ScanRoot }
        default       { @() }
    })

    if (-not $Fast -and $diag.extra_cmd -and (Test-ToolAvailable -Command $diag.check_cmd)) {
        $extraCmd = Expand-Template -Template $diag.extra_cmd -Values $values
        $extraOut = (Invoke-Expression "$extraCmd 2>&1" | Out-String)
        $extraResults = @(switch ($diag.style) {
            'gcc' { _Supra-ParseGcc -Lines ($extraOut -split "`r?`n") -ScanRoot $ScanRoot }
            default { @() }
        })
        $results = @($results) + @($extraResults)
    }

    # $results is already guaranteed array-typed by the @(...) wraps above, so
    # returning it plainly is correct here -- prefixing with ',' would nest it
    # in another array instead of protecting a scalar, which is a DIFFERENT bug.
    return $results
}

function supra {
    param(
        [Parameter(Position = 0)]
        [string]$ScanPath = ".",

        [string]$Std,
        [string[]]$Inc,
        [switch]$Fast,
        [switch]$ShowAll,
        [string]$Out
    )

    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    if (-not (Test-Path -LiteralPath $ScanPath)) {
        Write-Host ""
        Write-Host "  Path not found: $ScanPath" -ForegroundColor Red
        Write-Host ""
        return
    }
    $root = (Resolve-Path -LiteralPath $ScanPath).ProviderPath
    $registry = Get-LangRegistry
    if ($null -eq $registry) { return }

    Write-DevBanner -Title "supra :: scanning $root" -Color "Magenta"

    # Build extension -> language lookup dynamically from the registry.
    $extToLang = @{}
    foreach ($prop in $registry.languages.PSObject.Properties) {
        foreach ($ext in $prop.Value.extensions) { $extToLang[$ext] = $prop.Name }
    }

    $allFiles = Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $extToLang.ContainsKey($_.Extension) -or ($_.Name -in @($registry.languages.PSObject.Properties.Value.filenames | Where-Object { $_ })) }

    if (-not $allFiles) {
        Write-Host ""
        Write-Host "  No recognized source files under $root" -ForegroundColor Yellow
        Write-Host ""
        return
    }

    $byLang = @{}
    $reportLines = New-Object System.Collections.Generic.List[string]
    $totals = @{ Error = 0; Warning = 0; Suggestion = 0 }
    $perLangTotals = @{}
    $skippedTools = New-Object System.Collections.Generic.List[string]

    foreach ($file in $allFiles) {
        $langId = $extToLang[$file.Extension]
        if (-not $langId) {
            foreach ($prop in $registry.languages.PSObject.Properties) {
                if ($prop.Value.filenames -and ($prop.Value.filenames -contains $file.Name)) { $langId = $prop.Name; break }
            }
        }
        if (-not $langId) { continue }
        if (-not $byLang.ContainsKey($langId)) { $byLang[$langId] = New-Object System.Collections.Generic.List[object] }
        $byLang[$langId].Add($file)
    }

    foreach ($langId in ($byLang.Keys | Sort-Object)) {
        $entry = $registry.languages.$langId
        $files = $byLang[$langId]
        $diag = $entry.diagnostics

        if (-not $diag -or $diag.style -eq 'none') {
            continue
        }
        if (-not (Test-ToolAvailable -Command $diag.check_cmd)) {
            $skippedTools.Add("$($entry.label): $($diag.install_hint)")
            continue
        }

        $perLangTotals[$langId] = @{ Error = 0; Warning = 0; Suggestion = 0; Files = $files.Count }
        $langHadOutput = $false

        foreach ($file in $files) {
            $results = @(_Supra-RunDiagnostics -LangEntry $entry -FilePath $file.FullName -ScanRoot $root -Std $Std -Inc $Inc -Fast:$Fast)
            if ($results.Count -eq 0) {
                if ($ShowAll) {
                    $reportLines.Add("  [$($entry.label)] $($file.FullName.Substring($root.Length).TrimStart('\','/'))  -- clean")
                }
                continue
            }
            $langHadOutput = $true
            $relPath = $file.FullName
            if ($relPath.StartsWith($root)) { $relPath = $relPath.Substring($root.Length).TrimStart('\', '/') }
            $reportLines.Add("")
            $reportLines.Add("  [$($entry.label)] $relPath")
            foreach ($item in ($results | Sort-Object Line)) {
                $totals[$item.Severity]++
                $perLangTotals[$langId][$item.Severity]++
                $tag = switch ($item.Severity) { 'Error' { 'ERROR  ' } 'Warning' { 'WARN   ' } default { 'NOTE   ' } }
                $reportLines.Add("      $tag line $($item.Line): $($item.Message)")
            }
        }
    }

    foreach ($line in $reportLines) {
        $color = if ($line -match 'ERROR') { 'Red' } elseif ($line -match 'WARN') { 'Yellow' } elseif ($line -match '^\s*\[') { 'Cyan' } else { 'DarkGray' }
        Write-Host $line -ForegroundColor $color
    }

    Write-Host ""
    Write-Host "  ------------------------------------------------------------" -ForegroundColor DarkGray
    Write-Host "  Summary" -ForegroundColor Cyan
    "{0,-14} {1,8} {2,8} {3,10} {4,10}" -f "Language", "Files", "Errors", "Warnings", "Notes" | Write-Host -ForegroundColor White
    foreach ($langId in ($perLangTotals.Keys | Sort-Object)) {
        $t = $perLangTotals[$langId]
        $label = $registry.languages.$langId.label
        "{0,-14} {1,8} {2,8} {3,10} {4,10}" -f $label, $t.Files, $t.Error, $t.Warning, $t.Suggestion | Write-Host
    }
    Write-Host ""
    Write-Host ("  TOTAL   errors: {0}   warnings: {1}   notes: {2}" -f $totals.Error, $totals.Warning, $totals.Suggestion) -ForegroundColor $(if ($totals.Error -gt 0) { 'Red' } elseif ($totals.Warning -gt 0) { 'Yellow' } else { 'Green' })

    if ($skippedTools.Count -gt 0) {
        Write-Host ""
        Write-Host "  Skipped (tool not on PATH):" -ForegroundColor DarkYellow
        foreach ($s in ($skippedTools | Sort-Object -Unique)) { Write-Host "    - $s" -ForegroundColor DarkYellow }
    }

    if ($Out) {
        $full = ($reportLines -join "`n")
        Set-Content -LiteralPath $Out -Value $full -Encoding utf8
        Write-Host ""
        Write-Host "  Report written to $Out" -ForegroundColor Green
    }

    $sw.Stop()
    Write-DevFooter -ExitCode $(if ($totals.Error -gt 0) { 1 } else { 0 }) -Seconds $sw.Elapsed.TotalSeconds
}