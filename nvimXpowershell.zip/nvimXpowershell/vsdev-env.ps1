function Enable-VsDevEnvironment {
    <#
    Makes cl.exe (and the INCLUDE/LIB paths it needs) available in THIS
    PowerShell session, the same way opening "Developer PowerShell for VS"
    would -- without needing that special shortcut. Safe to call every
    session: it's a no-op if cl.exe is already reachable.
    #>
    if (Get-Command cl.exe -ErrorAction SilentlyContinue) {
        return $true
    }

    $vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    if (-not (Test-Path $vswhere)) {
        return $false
    }

    $vsPath = & $vswhere -latest -prerelease -products * `
        -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
        -property installationPath
    if (-not $vsPath) {
        return $false
    }

    $vcvars = Join-Path $vsPath "VC\Auxiliary\Build\vcvars64.bat"
    if (-not (Test-Path $vcvars)) {
        return $false
    }

    $envOutput = cmd.exe /c "`"$vcvars`" && set"
    foreach ($line in $envOutput) {
        if ($line -match "^([^=]+)=(.*)$") {
            [System.Environment]::SetEnvironmentVariable($Matches[1], $Matches[2], "Process")
        }
    }

    return [bool](Get-Command cl.exe -ErrorAction SilentlyContinue)
}