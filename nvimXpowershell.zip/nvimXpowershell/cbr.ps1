# =====================================================================
#  cbr.ps1  --  Compile + Build + Run, for whatever language the file is.
#
#  Data-driven: cbr has no per-language logic. It looks the file's
#  extension up in registry\languages.json and runs the build_cmd /
#  run_cmd template stored there. Adding a new language to that JSON
#  file is all that's needed for cbr to support it -- no edits here.
# =====================================================================

. (Join-Path (Split-Path -Parent $PSCommandPath) "devenv-lib.ps1")

function cbr {
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$File,

        [Alias("o")]
        [string]$Output,

        [string]$Std,

        [string[]]$Inc
    )

    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    if (-not (Test-Path -LiteralPath $File)) {
        Write-Host ""
        Write-Host "  File not found: $File" -ForegroundColor Red
        Write-Host ""
        return
    }
    $resolved = (Resolve-Path -LiteralPath $File).ProviderPath
    $lang = Find-LangEntry -Path $resolved

    if ($null -eq $lang) {
        $ext = [System.IO.Path]::GetExtension($resolved)
        Write-Host ""
        Write-Host "  No registry entry for '$ext' files yet." -ForegroundColor Yellow
        Write-Host "  Known extensions: $(Get-KnownExtensionsSummary)" -ForegroundColor Gray
        Write-Host "  Open a file of this type in Neovim once to auto-register it, or add" -ForegroundColor Gray
        Write-Host "  an entry yourself to:" -ForegroundColor Gray
        Write-Host "    $script:RegistryPath" -ForegroundColor Gray
        Write-Host ""
        return
    }

    $entry = $lang.Entry
    $run   = $entry.run
    $dir   = [System.IO.Path]::GetDirectoryName($resolved)
    $base  = [System.IO.Path]::GetFileNameWithoutExtension($resolved)

    Write-DevBanner -Title "cbr :: $($entry.label) :: $(Split-Path -Leaf $resolved)"

    switch ($run.kind) {

        "none" {
            Write-Host ""
            if ($run.message) { Write-Host "  $($run.message)" -ForegroundColor Yellow }
            else { Write-Host "  $($entry.label) files aren't runnable on their own." -ForegroundColor Yellow }
            Write-Host ""
            return
        }

        "open" {
            Write-Host ""
            Write-Host "  Opening in your default browser..." -ForegroundColor Cyan
            Start-Process $resolved
            Add-CliConfirmedLang -LangId $lang.Id
            $sw.Stop()
            Write-DevFooter -ExitCode 0 -Seconds $sw.Elapsed.TotalSeconds
            return
        }

        "exec" {
            if (-not (Request-ToolInstall -Label $entry.label -CheckCmd $run.check_cmd `
                        -InstallHint $run.install_hint -WingetId $run.winget_id)) {
                return
            }

            $effectiveStd = if ($Std) { $Std } elseif ($run.default_std) { $run.default_std } else { "" }
            $incFlags = ""
            if ($Inc) { $incFlags = (($Inc | ForEach-Object { "-I `"$_`"" }) -join " ") }

            if (-not $Output) {
                $outExt = if ($run.output_ext) { $run.output_ext } else { "" }
                $Output = Join-Path $dir "$base$outExt"
            } elseif ([string]::IsNullOrEmpty((Split-Path -Parent $Output))) {
                # Bare filename with no directory component -- put it next to the source file.
                $Output = Join-Path $dir $Output
            }

            $values = @{
                file   = $resolved
                dir    = $dir
                basename = $base
                output = $Output
                std    = $effectiveStd
                inc    = $incFlags
            }

            if ($run.build_cmd) {
                $buildCmd = Expand-Template -Template $run.build_cmd -Values $values
                Write-Host ""
                Write-Host "  > $buildCmd" -ForegroundColor DarkGray
                Invoke-Expression $buildCmd
                if ($LASTEXITCODE -ne 0) {
                    Write-Host ""
                    Write-Host "  Build failed (exit code $LASTEXITCODE)." -ForegroundColor Red
                    $sw.Stop()
                    Write-DevFooter -ExitCode $LASTEXITCODE -Seconds $sw.Elapsed.TotalSeconds
                    return
                }
            }

            $runCmd = Expand-Template -Template $run.run_cmd -Values $values
            Write-Host "  > $runCmd" -ForegroundColor DarkGray
            Write-Host ""
            Invoke-Expression $runCmd
            $finalExit = $LASTEXITCODE
            if ($null -eq $finalExit) { $finalExit = 0 }

            if ($run.cleanup) {
                foreach ($pattern in $run.cleanup) {
                    $target = Expand-Template -Template $pattern -Values $values
                    Get-ChildItem -Path $dir -Filter $target -ErrorAction SilentlyContinue |
                        Remove-Item -Force -ErrorAction SilentlyContinue
                }
            }

            Add-CliConfirmedLang -LangId $lang.Id
            $sw.Stop()
            Write-DevFooter -ExitCode $finalExit -Seconds $sw.Elapsed.TotalSeconds
            return
        }

        default {
            Write-Host ""
            Write-Host "  Unrecognized run.kind '$($run.kind)' for $($entry.label) in languages.json." -ForegroundColor Red
            Write-Host ""
            return
        }
    }
}